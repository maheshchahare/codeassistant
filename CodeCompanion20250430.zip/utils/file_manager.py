"""
File manager utility for handling session storage operations.
Uses optimized JSON file I/O with better error handling.
"""

import json
import logging
import os
import time
from pathlib import Path
from typing import Dict, List, Any, Optional

# Set up logging
logger = logging.getLogger("code_assistant.file_manager")

# Configure paths
DATA_DIR = Path("data")
SESSION_DIR = DATA_DIR / "sessions"
SESSIONS_INDEX_FILE = DATA_DIR / "sessions_index.json"


def ensure_directories(*dirs):
    """Ensure all specified directories exist."""
    for directory in dirs:
        directory.mkdir(parents=True, exist_ok=True)


def safe_read_json(file_path: Path) -> Dict:
    """Safely read a JSON file with error handling and retries."""
    max_retries = 3
    retry_delay = 0.5
    
    for attempt in range(max_retries):
        try:
            if not file_path.exists():
                return {}
            
            with open(file_path, "r", encoding="utf-8") as f:
                return json.load(f)
                
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding JSON from {file_path}: {e}")
            
            # Check if file is empty or corrupted
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                if not content:  # Empty file
                    logger.warning(f"File {file_path} is empty. Returning empty dict.")
                    return {}
            except Exception:
                pass
                
            if attempt < max_retries - 1:
                logger.info(f"Retrying JSON read in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logger.error(f"Failed to read JSON after {max_retries} attempts.")
                # Return empty data as fallback
                return {}
                
        except (IOError, OSError) as e:
            logger.error(f"IO error reading {file_path}: {e}")
            if attempt < max_retries - 1:
                logger.info(f"Retrying file read in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logger.error(f"Failed to read file after {max_retries} attempts.")
                return {}
    
    return {}


def safe_write_json(file_path: Path, data: Dict) -> bool:
    """Safely write data to a JSON file with atomic write pattern."""
    temp_file = file_path.with_suffix('.tmp')
    max_retries = 3
    retry_delay = 0.5
    
    for attempt in range(max_retries):
        try:
            # Write to temporary file first
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                
            # Ensure write is flushed to disk
            os.fsync(f.fileno())
            
            # Rename temp file to target file (atomic operation)
            temp_file.replace(file_path)
            return True
            
        except (IOError, OSError) as e:
            logger.error(f"IO error writing to {file_path}: {e}")
            if attempt < max_retries - 1:
                logger.info(f"Retrying file write in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logger.error(f"Failed to write file after {max_retries} attempts.")
                # Clean up temporary file if it exists
                if temp_file.exists():
                    try:
                        temp_file.unlink()
                    except Exception:
                        pass
                return False
    
    return False


def load_sessions_file() -> List[Dict]:
    """Load the sessions index file with better error handling."""
    try:
        ensure_directories(DATA_DIR)
        data = safe_read_json(SESSIONS_INDEX_FILE)
        
        # Ensure we return a list
        if not isinstance(data, list):
            logger.warning(f"Sessions index file contained {type(data)} instead of list. Resetting.")
            return []
            
        return data
    except Exception as e:
        logger.error(f"Unexpected error loading sessions index: {e}")
        return []


def save_sessions_file(sessions: List[Dict]) -> bool:
    """Save sessions to the index file."""
    try:
        ensure_directories(DATA_DIR)
        return safe_write_json(SESSIONS_INDEX_FILE, sessions)
    except Exception as e:
        logger.error(f"Unexpected error saving sessions index: {e}")
        return False


def get_session_by_id(session_id: str) -> Optional[Dict]:
    """Get a session by its ID from individual session files."""
    try:
        ensure_directories(DATA_DIR, SESSION_DIR)
        session_file = SESSION_DIR / f"{session_id}.json"
        
        if not session_file.exists():
            return None
            
        return safe_read_json(session_file)
    except Exception as e:
        logger.error(f"Error retrieving session {session_id}: {e}")
        return None


def create_session_file(session_id: str, session_data: Dict) -> bool:
    """Create a new session file."""
    try:
        ensure_directories(DATA_DIR, SESSION_DIR)
        session_file = SESSION_DIR / f"{session_id}.json"
        
        # Don't overwrite existing session
        if session_file.exists():
            logger.warning(f"Session file {session_id}.json already exists. Not overwriting.")
            return False
            
        return safe_write_json(session_file, session_data)
    except Exception as e:
        logger.error(f"Error creating session file {session_id}: {e}")
        return False


def update_session_file(session_id: str, session_data: Dict) -> bool:
    """Update an existing session file."""
    try:
        ensure_directories(DATA_DIR, SESSION_DIR)
        session_file = SESSION_DIR / f"{session_id}.json"
        
        return safe_write_json(session_file, session_data)
    except Exception as e:
        logger.error(f"Error updating session file {session_id}: {e}")
        return False


def delete_session_file(session_id: str) -> bool:
    """Delete a session file."""
    try:
        session_file = SESSION_DIR / f"{session_id}.json"
        
        if not session_file.exists():
            logger.warning(f"Session file {session_id}.json does not exist.")
            return False
            
        session_file.unlink()
        return True
    except Exception as e:
        logger.error(f"Error deleting session file {session_id}: {e}")
        return False
