// Global variables
const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');
const modelSelect = document.getElementById('model-select');
const languageSelect = document.getElementById('language-select');
const taskSelect = document.getElementById('task-select');
const clearChatButton = document.getElementById('clear-chat');
const checkHealthButton = document.getElementById('check-health');
const toggleSettingsButton = document.getElementById('toggle-settings');
const settingsPanel = document.getElementById('settings-panel');
const overlay = document.getElementById('overlay');
const sessionList = document.getElementById('session-list');
const createSessionButton = document.getElementById('create-session-btn');
const sessionsSidebar = document.querySelector('.sessions-sidebar');
const toggleSidebarBtn = document.getElementById('toggle-sidebar');
const emptyState = document.getElementById('empty-state');

// Initialize session management
let currentSessionId = localStorage.getItem('currentSessionId') || null;
let sessions = [];

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Initialize the first session if none exists
    initializeSessions();
    
    sendButton.addEventListener('click', handleSendMessage);
    userInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    });
    
    clearChatButton.addEventListener('click', clearChat);
    checkHealthButton.addEventListener('click', checkHealth);
    toggleSettingsButton.addEventListener('click', toggleSettings);
    // No overlay click handler needed
    createSessionButton.addEventListener('click', createNewSession);
    toggleSidebarBtn.addEventListener('click', toggleSidebar);
    
    // Auto-resize textarea
    userInput.addEventListener('input', autoResizeTextarea);
    
    // Fetch available models
    fetchAvailableModels();
});

// Session Management Functions
function initializeSessions() {
    // First try to fetch sessions from the server
    fetch('/sessions')
        .then(response => response.json())
        .then(data => {
            if (data && data.length > 0) {
                sessions = data;
                loadSessions();
                
                // Set current session
                if (!currentSessionId || !sessions.some(session => session.id === currentSessionId)) {
                    currentSessionId = sessions[0].id;
                    localStorage.setItem('currentSessionId', currentSessionId);
                }
                
                // Load messages for current session
                loadSessionMessages(currentSessionId);
                
                // Mark current session as active
                updateActiveSession();
            } else {
                // If no sessions on server, create a new one
                createNewSession();
            }
        })
        .catch(error => {
            console.error('Error loading sessions:', error);
            // Use local fallback or create a new session
            sessions = JSON.parse(localStorage.getItem('sessions')) || [];
            if (sessions.length === 0) {
                createNewSession();
            } else {
                loadSessions();
                if (!currentSessionId || !sessions.some(session => session.id === currentSessionId)) {
                    currentSessionId = sessions[0].id;
                    localStorage.setItem('currentSessionId', currentSessionId);
                }
                loadSessionMessages(currentSessionId);
                updateActiveSession();
            }
        });
}

function loadSessions() {
    sessionList.innerHTML = '';  // Clear existing session list

    sessions.forEach(session => {
        const sessionItem = document.createElement('li');
        sessionItem.dataset.id = session.id;
        sessionItem.className = 'session-item';
        if (session.id === currentSessionId) {
            sessionItem.classList.add('active');
        }
        
        const icon = document.createElement('i');
        icon.className = 'fas fa-comment-dots';
        
        const sessionName = document.createElement('span');
        sessionName.textContent = session.name;
        
        sessionItem.appendChild(icon);
        sessionItem.appendChild(sessionName);
        
        sessionItem.addEventListener('click', () => switchSession(session.id));
        sessionList.appendChild(sessionItem);
    });
}

async function createNewSession() {
    try {
        const response = await fetch('/sessions', { method: 'POST' });
        if (!response.ok) {
            throw new Error(`Failed to create session: ${response.statusText}`);
        }
        
        const data = await response.json();
        
        const newSessionId = data.id;
        const sessionName = data.name;

        // Update the sessions array
        await fetch('/sessions')
            .then(response => response.json())
            .then(data => {
                sessions = data;
            });

        // Switch to the new session
        currentSessionId = newSessionId;
        localStorage.setItem('currentSessionId', currentSessionId);

        loadSessions();
        clearChatSilent();
        updateActiveSession();
        showEmptyState();
        loadSessionMessages(currentSessionId);  // Re-evaluate UI
        
        // Mobile: close sidebar after creating new session
        // if (window.innerWidth <= 768) {
        //     closeSidebar();
        // }
        closeSidebar();
    } catch (error) {
        console.error('Error creating session:', error);
        showToast('Failed to create a new session', 'danger');
    }
}

function switchSession(sessionId) {
    if (sessionId === currentSessionId) return;
    
    // Save current messages if needed
    saveSessionMessages(currentSessionId);
    
    // Switch to selected session
    currentSessionId = sessionId;
    localStorage.setItem('currentSessionId', currentSessionId);
    
    // Clear chat and load session messages
    clearChatSilent();
    loadSessionMessages(sessionId);
    
    // Update active session in UI
    updateActiveSession();
    
    // Close sidebar on mobile after switching
    if (window.innerWidth <= 768) {
        closeSidebar();
    }
}

function updateActiveSession() {
    // Remove active class from all sessions
    document.querySelectorAll('.session-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Add active class to current session
    const activeItem = document.querySelector(`.session-item[data-id="${currentSessionId}"]`);
    if (activeItem) {
        activeItem.classList.add('active');
    }
}

function saveSessionMessages(sessionId) {
    // Find the session in our array
    const sessionIndex = sessions.findIndex(s => s.id === sessionId);
    if (sessionIndex === -1) return;
    
    // Get all messages from the chat and convert to storable format
    const messageElements = chatMessages.querySelectorAll('.message');
    const messages = Array.from(messageElements).map(el => {
        const isUser = el.classList.contains('user-message');
        const content = el.querySelector('.message-content').innerHTML;
        const timestamp = new Date().toISOString();
        return { content, isUser, timestamp };
    });
    
    // Send to the server
    fetch(`/sessions/${sessionId}/messages`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(messages)
    }).catch(error => {
        console.error('Error saving session messages:', error);
    });
}

function loadSessionMessages(sessionId) {
    // Fetch the specific session from the server
    fetch(`/sessions/${sessionId}`)
        .then(response => {
            if (!response.ok) throw new Error(`Failed to load session: ${response.statusText}`);
            return response.json();
        })
        .then(session => {
            if (session && session.messages && session.messages.length > 0) {
                hideEmptyState();
                // Add each message to the chat
                session.messages.forEach(msg => {
                    if (msg.isUser) {
                        addUserMessageRaw(msg.content);
                    } else {
                        addBotMessageRaw(msg.content);
                    }
                });
            } else {
                showEmptyState();
            }
        })
        .catch(error => {
            console.error('Error loading session messages:', error);
            showEmptyState();
        });
}

// UI toggle functions
function toggleSidebar() {
    sessionsSidebar.classList.toggle('show');
    // No need to show overlay anymore
}

function closeSidebar() {
    sessionsSidebar.classList.remove('show');
    // No need to handle overlay
}

function toggleSettings() {
    settingsPanel.classList.toggle('show');
    
    // Add settings-open class to chat panel to coordinate animations
    const chatPanel = document.querySelector('.chat-panel');
    if (settingsPanel.classList.contains('show')) {
        chatPanel.classList.add('settings-open');
    } else {
        chatPanel.classList.remove('settings-open');
    }
}

function closeSettings() {
    settingsPanel.classList.remove('show');
    
    // Remove settings-open class from chat panel
    const chatPanel = document.querySelector('.chat-panel');
    chatPanel.classList.remove('settings-open');
}

// Format and display response
function displayQueryResponse(data) {
    const { response, tone } = data;
    
    if (tone === 'code') {
        // Format code blocks in the response
        const formattedResponse = enhanceCodeBlocks(response);
        addBotMessageRaw(formattedResponse);
    } else {
        // For conversation tone, just display the text
        addBotMessage(response);
    }
}


// Function to enhance code blocks with syntax highlighting
function enhanceCodeBlocks(text) {
    // Replace code blocks with properly formatted HTML
    return text.replace(/```([\s\S]*?)```/g, (match, codeContent) => {
        const language = codeContent.split('\n')[0].trim();
        const actualCode = language ? codeContent.substring(language.length).trim() : codeContent.trim();
        
        return `<div class="code-block-container" style="position: relative;">
                    <button class="code-copy-button" onclick="copyToClipboard(\`${actualCode.replace(/`/g, '\\`')}\`)" style="position: absolute; top: 10px; right: 10px; z-index: 10;">
                        <i class="fas fa-copy"></i>
                    </button>
                    <pre><code class="language-${language || 'plaintext'}">${escapeHtml(actualCode)}</code></pre>
                </div>`;
    });
}

// Send Message Function
async function handleSendMessage() {
    const message = userInput.value.trim();
    if (!message) return;
    
    // Hide empty state if visible
    hideEmptyState();
    
    // Display user message
    addUserMessage(message);

    // Clear input
    userInput.value = '';
    userInput.style.height = 'auto'; // reset height

    // Show loading
    const loadingId = addLoadingMessage();
    
    try {
        const requestData = {
            query: message,
            language: languageSelect.value,
            task: taskSelect.value,
            model: modelSelect.value,
            sessionId: currentSessionId,
            includeHistory: true,
            historyLimit: 10
        };
        
        const response = await fetch('/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestData)
        });
        
        removeLoadingMessage(loadingId);
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Error: ${response.status}`);
        }

        const data = await response.json();
        
        // Display bot response
        displayQueryResponse(data);
        
        // Save after bot responds
        saveSessionMessages(currentSessionId);
        
        // Update session name with the first message if it's still using default name
        updateSessionName(message);
    } catch (error) {
        console.error('Error:', error);
        removeLoadingMessage(loadingId);
        addErrorMessage(error.message, message);
        saveSessionMessages(currentSessionId);
    }
}

// Add an error message in response to a failed query
function addErrorMessage(errorText, originalMessage) {
    const errorMessage = `
        <div class="alert alert-danger">
            <strong>Error:</strong> ${errorText}
        </div>
        <p>If Ollama is not available, make sure it's running on your local machine.</p>
    `;
    addBotMessageRaw(errorMessage);
}

// Update session name with first few words of first message
function updateSessionName(message) {
    const session = sessions.find(s => s.id === currentSessionId);
    if (!session) return;
    
    // Only update if it's using the default name format
    if (session.name.startsWith('Chat ')) {
        // Get first 3-4 words of message
        const words = message.split(' ');
        let newName = words.slice(0, Math.min(4, words.length)).join(' ');
        
        // Truncate if too long and add ellipsis
        if (newName.length > 30) {
            newName = newName.substring(0, 27) + '...';
        }
        
        // Update in local array
        session.name = newName;
        
        // Update in localStorage
        localStorage.setItem('sessions', JSON.stringify(sessions));
        
        // Refresh the UI
        loadSessions();
    }
}

// Check API health 
async function checkHealth() {
    try {
        const response = await fetch('/health');
        const data = await response.json();
        
        if (data.status === 'ok') {
            let message = 'API connection successful! ';
            if (data.ollama_available) {
                message += 'Ollama service is connected and ready.';
                showToast(message, 'success');
            } else {
                message += 'Warning: Ollama service is not available. Please make sure Ollama is running on your local machine.';
                showToast(message, 'warning');
            }
        } else {
            showToast('API health check failed.', 'danger');
        }
    } catch (error) {
        console.error('Health check error:', error);
        showToast('Failed to connect to the API. Please check if the server is running.', 'danger');
    }
}

// Fetch available models
async function fetchAvailableModels() {
    try {
        const response = await fetch('/models');
        if (!response.ok) return;
        
        const data = await response.json();
        
        // Clear and repopulate model selector
        modelSelect.innerHTML = '';
        
        if (data.models && data.models.length > 0) {
            data.models.forEach(model => {
                const option = document.createElement('option');
                option.value = model;
                option.textContent = model;
                modelSelect.appendChild(option);
            });
        } else {
            // Add default options if no models are found
            const defaultModels = ['codellama', 'llama3', 'mistral', 'mixtral'];
            defaultModels.forEach(model => {
                const option = document.createElement('option');
                option.value = model;
                option.textContent = model;
                modelSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error fetching models:', error);
    }
}

// Utility functions for displaying messages
function addUserMessage(content) {
    const escapedContent = escapeHtml(content);
    addUserMessageRaw(escapedContent);
}

function addUserMessageRaw(content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user-message';
    
    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';
    messageContent.innerHTML = content;
    
    messageDiv.appendChild(messageContent);
    chatMessages.appendChild(messageDiv);
    
    scrollToBottom();
}

function addBotMessage(content) {
    const escapedContent = escapeHtml(content);
    addBotMessageRaw(escapedContent);
}

function addBotMessageRaw(content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot-message';
    
    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';
    messageContent.innerHTML = content;
    
    messageDiv.appendChild(messageContent);
    chatMessages.appendChild(messageDiv);
    
    scrollToBottom();
}

function addLoadingMessage() {
    const loadingId = 'loading-' + Date.now();
    const loadingDiv = document.createElement('div');
    loadingDiv.id = loadingId;
    loadingDiv.className = 'loading';
    
    const spinner = document.createElement('div');
    spinner.className = 'loading-spinner';
    
    const loadingText = document.createElement('span');
    loadingText.textContent = 'Processing...';
    
    loadingDiv.appendChild(spinner);
    loadingDiv.appendChild(loadingText);
    chatMessages.appendChild(loadingDiv);
    
    scrollToBottom();
    return loadingId;
}

function removeLoadingMessage(id) {
    const loadingDiv = document.getElementById(id);
    if (loadingDiv) {
        loadingDiv.remove();
    }
}

function clearChat() {
    chatMessages.innerHTML = '';
    showEmptyState();
    
    // Also clear server-side
    saveSessionMessages(currentSessionId);
}

function clearChatSilent() {
    chatMessages.innerHTML = '';
}

function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function autoResizeTextarea() {
    userInput.style.height = 'auto'; // Reset height
    userInput.style.height = (userInput.scrollHeight) + 'px';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Show/hide empty state
function showEmptyState() {
    if (emptyState) {
        emptyState.style.display = 'flex';
    }
}

function hideEmptyState() {
    if (emptyState) {
        emptyState.style.display = 'none';
    }
}

// Handle example query clicks
function useExampleQuery(element) {
    userInput.value = element.textContent.trim();
    autoResizeTextarea();
    handleSendMessage();
}

// Toast notifications
function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    createToastContainer();
    
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = `toast show bg-${type} text-white`;
    toast.id = toastId;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="toast-header bg-${type} text-white">
            <strong class="me-auto">Notification</strong>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close" 
                onclick="document.getElementById('${toastId}').remove()"></button>
        </div>
        <div class="toast-body">
            ${message}
        </div>
    `;
    
    const toastContainer = document.getElementById('toast-container');
    toastContainer.appendChild(toast);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        const toastElement = document.getElementById(toastId);
        if (toastElement) {
            toastElement.remove();
        }
    }, 5000);
}

function createToastContainer() {
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
}

// Utility for copying code to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text)
        .then(() => {
            showToast('Code copied to clipboard!', 'success');
        })
        .catch(err => {
            console.error('Failed to copy text: ', err);
            showToast('Failed to copy code', 'danger');
        });
}