"""
Utilities for interacting with language models and handling responses.
Improved error handling and response extraction.
"""

import json
import logging
import re
import html
from typing import Dict, Optional
import httpx

# Set up logging
logger = logging.getLogger("code_assistant.llm_utils")


async def check_ollama_available(api_base: str) -> bool:
    """Check if Ollama API is available with better error handling."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{api_base}/tags", timeout=5.0)
            return response.status_code == 200
    except httpx.ConnectError:
        logger.error(f"Connection error: Unable to connect to Ollama at {api_base}")
        return False
    except httpx.ReadTimeout:
        logger.error(f"Timeout: Ollama request timed out at {api_base}")
        return False
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error: {e.response.status_code} - {e.response.text}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error checking Ollama availability: {e}")
        return False


async def query_ollama(prompt: str, model: str, api_base: str) -> str:
    """Send a prompt to Ollama API with improved error handling and retry logic."""
    max_retries = 2
    retry_delay = 1
    
    for attempt in range(max_retries + 1):
        try:
            async with httpx.AsyncClient() as client:
                logger.info(f"Sending request to Ollama with model: {model}")
                
                response = await client.post(
                    f"{api_base}/generate",
                    json={"model": model, "prompt": prompt, "stream": False},
                    timeout=60.0,  # Increased timeout for longer responses
                )
                
                # Handle non-200 responses
                if response.status_code != 200:
                    error_msg = f"Ollama API returned {response.status_code}: {response.text}"
                    logger.error(error_msg)
                    
                    if attempt < max_retries:
                        logger.info(f"Retrying Ollama query (attempt {attempt+1}/{max_retries})")
                        continue
                    
                    # Use a fallback message on final failure
                    return "I'm having trouble connecting to the language model right now. Please try again in a moment."
                
                result = response.json()
                llm_response = result.get("response", "")
                
                # Check if response is empty
                if not llm_response.strip():
                    logger.warning("Received empty response from Ollama")
                    
                    if attempt < max_retries:
                        logger.info(f"Retrying Ollama query (attempt {attempt+1}/{max_retries})")
                        continue
                    
                    return "I received an empty response. Please try rephrasing your question."
                
                return llm_response
                
        except httpx.ConnectError:
            logger.error(f"Connection error on attempt {attempt+1}/{max_retries+1}")
            if attempt < max_retries:
                logger.info(f"Retrying in {retry_delay} seconds...")
                await httpx.AsyncClient().aclose()  # Ensure client is closed
                import asyncio
                await asyncio.sleep(retry_delay)
            else:
                return "I'm having trouble connecting to the language model. Please check if Ollama is running."
                
        except httpx.ReadTimeout:
            logger.error(f"Request timed out on attempt {attempt+1}/{max_retries+1}")
            if attempt < max_retries:
                logger.info(f"Retrying with a simplified prompt...")
                # Simplify the prompt for retry to avoid timeout
                if len(prompt) > 4000:
                    prompt = prompt[:4000] + "...\n\nPlease provide a concise response."
            else:
                return "The request timed out. Please try a shorter prompt or try again later."
                
        except Exception as e:
            logger.error(f"Error querying Ollama on attempt {attempt+1}/{max_retries+1}: {e}")
            if attempt < max_retries:
                logger.info(f"Retrying in {retry_delay} seconds...")
                import asyncio
                await asyncio.sleep(retry_delay)
            else:
                return f"An error occurred while processing your request: {str(e)}. Please try again later."
    
    # Fallback message if all attempts fail
    return "I'm having difficulty processing your request right now. Please try again later."


def sanitize_input(text: str) -> str:
    """Sanitize user input to prevent injection attacks."""
    if not text:
        return ""
    
    # Remove any potentially harmful HTML 
    clean_text = html.escape(text)
    
    # Prevent prompt injection with delimiters
    clean_text = clean_text.replace("{", "{{").replace("}", "}}")
    
    return clean_text


def strip_html_tags(text: str) -> str:
    """Remove HTML tags from text to clean it for LLM input."""
    if not text:
        return ""
        
    # Simple regex to remove HTML tags
    clean_text = re.sub(r"<[^>]+>", "", text)
    
    # Also decode any HTML entities
    clean_text = html.unescape(clean_text)
    
    return clean_text


def extract_json_from_text(text: str) -> Dict:
    """Extract JSON object from LLM response with improved parsing."""
    # Try to find JSON object in the text
    json_match = re.search(r"({[\s\S]*})", text)
    if json_match:
        try:
            # Try to parse the extracted JSON
            json_str = json_match.group(1)
            # Fix common issues like unquoted keys
            json_str = re.sub(r'([{,])\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*:', r'\1"\2":', json_str)
            return json.loads(json_str)
        except json.JSONDecodeError:
            # If JSON parsing fails, proceed to fallback
            pass
    
    # Fallback for when the model doesn't strictly follow JSON format
    try:
        # Try to extract sections using regex patterns
        improved_code_match = re.search(r"```[\w]*\n([\s\S]*?)\n```", text)
        improved_code = improved_code_match.group(1) if improved_code_match else ""
        
        # If no code block found, look for code without backticks
        if not improved_code and "```" not in text:
            code_sections = re.findall(r"(?:here is the|improved|refactored|optimized) code:?\s*([\s\S]+?)(?=\n\n|$)", text, re.IGNORECASE)
            if code_sections:
                improved_code = code_sections[0].strip()
        
        explanation_pattern = r"(?:explanation|explanation:)([\s\S]*?)(?:suggestions|recommendations|$)"
        explanation_match = re.search(explanation_pattern, text, re.IGNORECASE)
        explanation = explanation_match.group(1).strip() if explanation_match else ""
        
        # If no structured explanation found, use everything before the suggestions
        if not explanation:
            explanation_parts = text.split("suggestions:", 1)
            if len(explanation_parts) > 1:
                # Remove the code part if it exists
                possible_explanation = explanation_parts[0]
                if improved_code:
                    possible_explanation = possible_explanation.replace(improved_code, "")
                explanation = possible_explanation.strip()
        
        suggestions = []
        suggestions_text = re.search(r"suggestions:?([\s\S]*?)(?:$|conclusion|summary)", text, re.IGNORECASE)
        if suggestions_text:
            suggestions_raw = suggestions_text.group(1)
            # Extract numbered or bulleted items
            suggestions = re.findall(
                r"(?:^\d+\.|\*|-)\s*(.*?)(?=^\d+\.|\*|-|$)", suggestions_raw, re.MULTILINE
            )
            if not suggestions:
                # Split by newlines as fallback
                suggestions = [
                    s.strip() for s in suggestions_raw.split("\n") if s.strip()
                ]
        
        # If we still have no suggestions, look for keyword phrases
        if not suggestions:
            recommendation_phrases = [
                "you could", "you should", "consider", "try to", "it's better to",
                "i recommend", "i suggest", "a better approach"
            ]
            for phrase in recommendation_phrases:
                matches = re.findall(f"{phrase}(.*?)(?:\.|$)", text, re.IGNORECASE)
                suggestions.extend([match.strip() for match in matches if match.strip()])
        
        return {
            "improved_code": improved_code,
            "explanation": explanation or "Here's an improved version of your code.",
            "suggestions": suggestions[:3] if suggestions else [
                "Try to keep your code modular and maintainable",
                "Follow consistent naming conventions",
                "Add appropriate documentation to your code"
            ],
        }
    except Exception as e:
        logger.error(f"Error parsing LLM response: {e}")
        # Return error structure if parsing fails completely
        return {
            "improved_code": "Failed to parse code improvements",
            "explanation": "The AI response couldn't be properly parsed.",
            "suggestions": [
                "Try again with a simpler code snippet",
                "Ensure code is properly formatted",
                "Try a different task type",
            ],
        }
