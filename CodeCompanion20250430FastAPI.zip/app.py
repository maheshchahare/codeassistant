# Rewriting app.py from Flask to FastAPI based on previous evaluation and preserving all features.

from fastapi import FastAPI, HTTPException  # , Request
from fastapi.responses import HTMLResponse  # , JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

# from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional, List  # , Dict
from datetime import datetime
from pathlib import Path
import httpx
import json

# import os
import re

# Constants and setup
OLLAMA_API_BASE = "http://localhost:11434/api"
DEFAULT_MODEL = "codellama:latest"

app = FastAPI()

# Optional: Add CORS if needed
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure directories
Path("data/sessions").mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")


# Request models
class ImproveCodeRequest(BaseModel):
    code: str
    language: str
    task: Optional[str] = "improve"
    context: Optional[str] = None
    model: Optional[str] = DEFAULT_MODEL


class QueryRequest(BaseModel):
    query: str
    language: Optional[str] = None
    task: Optional[str] = None
    model: Optional[str] = DEFAULT_MODEL
    sessionId: Optional[str] = None
    includeHistory: Optional[bool] = True
    historyLimit: Optional[int] = 10


class Message(BaseModel):
    content: str
    isUser: bool
    timestamp: str


class SessionMetadataUpdate(BaseModel):
    name: Optional[str] = None


# Helper functions
def ensure_directories(*dirs):
    for d in dirs:
        Path(d).mkdir(parents=True, exist_ok=True)


def save_session_file(session_id: str, session_data: dict):
    try:
        with open(f"data/sessions/{session_id}.json", "w") as f:
            json.dump(session_data, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving session: {e}")
        return False


def load_sessions():
    path = Path("data/sessions.json")
    if not path.exists():
        return []
    with open(path, "r") as f:
        return json.load(f)


def save_sessions(sessions_data):
    try:
        with open("data/sessions.json", "w") as f:
            json.dump(sessions_data, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving sessions: {e}")
        return False


def get_session_by_id(session_id: str) -> Optional[dict]:
    session_file = Path(f"data/sessions/{session_id}.json")
    if not session_file.exists():
        return None
    with open(session_file, "r") as f:
        return json.load(f)


def strip_html_tags(text: str) -> str:
    return re.sub(r"<[^>]+>", "", text)


def get_chat_history(session_id: str, limit: int = 10) -> list:
    session = get_session_by_id(session_id)
    if not session or "messages" not in session:
        return []
    messages = session["messages"][-limit:]
    return [
        {
            "role": "user" if msg["isUser"] else "assistant",
            "content": strip_html_tags(msg["content"]),
        }
        for msg in messages
    ]


def check_ollama_available():
    try:
        with httpx.Client() as client:
            response = client.get(f"{OLLAMA_API_BASE}/tags", timeout=5.0)
            return response.status_code == 200
    except Exception:
        return False


def query_ollama(prompt: str, model: str = DEFAULT_MODEL) -> str:
    with httpx.Client() as client:
        try:
            response = client.post(
                f"{OLLAMA_API_BASE}/generate",
                json={"model": model, "prompt": prompt, "stream": False},
                timeout=180.0,
            )
            response.raise_for_status()
            result = response.json()
            return result.get("response", "")
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=response.status_code, detail=str(e))
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"Ollama error: {e}")


# Prompt creation and JSON extraction functions are unchanged
# (Use your existing `create_code_prompt`, `create_nl_prompt`, `extract_json_from_text`, `TASK_PROMPTS`, etc.)


# Task-specific prompts
TASK_PROMPTS = {
    "improve": "Improve this code to make it cleaner, more maintainable, and follow best practices.",
    "document": "Add appropriate documentation to this code following best practices.",
    "refactor": "Refactor this code to improve its structure while preserving functionality.",
    "optimize": "Optimize this code for better performance while maintaining readability.",
    "debug": "Identify and fix potential bugs or issues in this code.",
    "query": "Answer the following programming question or help with the code task.",
}


def create_nl_prompt(
    query: str, language: str = None, task: str = None, history: list = None
) -> str:
    """Craft a natural language programming prompt including chat history"""
    if history is None:
        history = []
    task_description = ""
    history_context = ""

    if history and len(history) > 0:
        history_formatted = "\n".join(
            [
                f"User: {msg['content'] if msg['role'] == 'user' else ''}"
                f"Assistant: {msg['content'] if msg['role'] == 'assistant' else ''}"
                for msg in history
            ]
        )
        history_context = f"\nChat History:\n{history_formatted}\n"

    # Set task description
    if task and task in TASK_PROMPTS:
        task_description = f"The user wants to {TASK_PROMPTS[task].lower()}"
    else:
        task_description = "help with programming questions"

    #     return f"""As an expert programmer, your task is to {task_description}
    # If user greets, then greet it back and say I am a code Assistant. How can I help you with coding? Do not provide much details in greeting
    # message. Just greet it back.

    # Focus on making the code more:
    # - Readable and maintainable
    # - Modular with proper separation of concerns
    # - Following best practices for {language if language else "any"} language
    # - Free of code smells and anti-patterns
    # - Well-documented when needed
    # {history_context}

    # Current Question:
    # {query}
    # Give code snippet to explain more clearly enclosed in ``````.

    # Please provide a clear, accurate, and helpful response.
    # """
    return f"""You are a helpful and expert code assistant.

If the user greets (e.g., "hi", "hello", "hey"), respond with a short friendly greeting like "Hello! I’m a code assistant. How can I help you with your code?" Do not provide technical explanations or elaborate details in such cases.

If the user asks a general question, respond in a clear and concise manner without unnecessary technical depth.

If the user asks a programming-related question or shares code, your task is to {task_description.lower()}.

Focus on making the code:
- Readable and maintainable
- Modular with proper separation of concerns
- Following best practices for {language if language else "any"} language
- Free of code smells and anti-patterns
- Well-documented where appropriate

{history_context}

Current User Input:
{query}

If applicable, include a code snippet enclosed in triple backticks (```) to support your explanation.

Always provide accurate, helpful, and to-the-point responses.
"""


def create_code_prompt(
    code: str, language: str, task: str = "improve", context: Optional[str] = None
) -> str:
    """Create a prompt for the LLM to process code."""
    task_description = TASK_PROMPTS.get(task, TASK_PROMPTS["improve"])

    prompt = f"""As an expert programmer, your task is to {task_description}
    
Code Language: {language}

{f"Context: {context}" if context else ""}

Original Code:
```{language}
{code}
```

Please provide:
1. An improved version of the code
2. A clear explanation of the changes made
3. Three specific recommendations for further improvement

Format your response in JSON with the following structure:
{{
    "improved_code": "your improved code here",
    "explanation": "your explanation here",
    "suggestions": ["suggestion1", "suggestion2", "suggestion3"]
}}

Focus on making the code more:
- Readable and maintainable
- Modular with proper separation of concerns
- Following best practices for {language}
- Free of code smells and anti-patterns
- Well-documented when needed
"""
    return prompt


def extract_json_from_text(text: str) -> dict:
    """Extract JSON object from text which might contain other content."""
    # Try to find JSON object in the text
    json_match = re.search(r"({[\s\S]*})", text)
    if json_match:
        try:
            return json.loads(json_match.group(1))
        except json.JSONDecodeError:
            pass

    # Fallback for when the model doesn't strictly follow JSON format
    try:
        # Try to extract sections using regex patterns
        improved_code_match = re.search(r"```[\w]*\n([\s\S]*?)\n```", text)
        improved_code = improved_code_match.group(1) if improved_code_match else ""

        explanation_pattern = r"(?:explanation|explanation:)([\s\S]*?)(?:suggestions|$)"
        explanation_match = re.search(explanation_pattern, text, re.IGNORECASE)
        explanation = explanation_match.group(1).strip() if explanation_match else ""

        suggestions = []
        suggestions_text = re.search(r"suggestions:?([\s\S]*?)$", text, re.IGNORECASE)
        if suggestions_text:
            suggestions_raw = suggestions_text.group(1)
            # Extract numbered or bulleted items
            suggestions = re.findall(
                r"(?:^\d+\.|\*)\s*(.*?)(?=^\d+\.|\*|$)", suggestions_raw, re.MULTILINE
            )
            if not suggestions:
                # Split by newlines as fallback
                suggestions = [
                    s.strip() for s in suggestions_raw.split("\n") if s.strip()
                ]

        return {
            "improved_code": improved_code,
            "explanation": explanation,
            "suggestions": suggestions[:3],  # Limit to 3 suggestions
        }
    except Exception:
        # Return error structure if parsing fails completely
        return {
            "improved_code": "Failed to parse code improvements",
            "explanation": "The AI response couldn't be properly parsed.",
            "suggestions": [
                "Try again with a simpler code snippet",
                "Ensure code is properly formatted",
                "Try a different task type",
            ],
        }


# Routes


@app.get("/", response_class=HTMLResponse)
async def home():
    with open("templates/index.html", "r", encoding="utf-8") as f:
        return f.read()


@app.get("/health")
async def health_check():
    return {
        "status": "ok",
        "ollama_available": check_ollama_available(),
        "timestamp": datetime.now().isoformat(),
    }


@app.get("/sessions")
async def list_sessions():
    return load_sessions()


@app.get("/sessions/{session_id}")
async def get_session(session_id: str):
    session = get_session_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session


@app.put("/sessions/{session_id}")
async def update_session_metadata(session_id: str, update: SessionMetadataUpdate):
    session = get_session_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    if update.name:
        session["name"] = update.name

        # Also update the session summary in the global list
        all_sessions = load_sessions()
        for s in all_sessions:
            if s["id"] == session_id:
                s["name"] = update.name
                break
        save_sessions(all_sessions)

    session["updated_at"] = datetime.now().isoformat()
    save_session_file(session_id, session)
    return {"status": "success", "session": session}


@app.post("/sessions")
async def create_session():
    session_id = f"session_{int(datetime.now().timestamp() * 1000)}"
    new_session = {
        "id": session_id,
        "name": f"Chat {datetime.now().strftime('%Y-%m-%d, %H:%M:%S')}",
        "messages": [],
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
    }
    save_session_file(session_id, new_session)
    sessions = load_sessions()
    sessions.insert(
        0,
        {
            "id": session_id,
            "name": new_session["name"],
            "created_at": new_session["created_at"],
        },
    )
    save_sessions(sessions)
    return {"id": session_id, "name": new_session["name"]}


@app.put("/sessions/{session_id}/messages")
async def update_session_messages(session_id: str, messages: List[Message]):
    session = get_session_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    session["messages"] = [msg.dict() for msg in messages]
    session["updated_at"] = datetime.now().isoformat()
    save_session_file(session_id, session)
    return {"status": "success"}


@app.get("/models")
async def list_models():
    try:
        with httpx.Client() as client:
            response = client.get(f"{OLLAMA_API_BASE}/tags", timeout=5.0)
            if response.status_code == 200:
                models = response.json()
                return {"models": [m["name"] for m in models["models"]]}
    except Exception as e:
        return {"models": [], "error": str(e)}
    return {"models": []}


@app.post("/improve-code")
async def improve_code(request: ImproveCodeRequest):
    if not check_ollama_available():
        raise HTTPException(status_code=503, detail="Ollama not available")

    prompt = create_code_prompt(
        request.code, request.language, request.task, request.context
    )
    response_text = query_ollama(prompt, request.model)
    suggestions = extract_json_from_text(response_text)
    return {
        "original_code": request.code,
        "suggestions": suggestions,
    }


@app.post("/query")
async def natural_language_query(request: QueryRequest):
    if not check_ollama_available():
        raise HTTPException(status_code=503, detail="Ollama not available")

    history = (
        get_chat_history(request.sessionId, request.historyLimit)
        if request.includeHistory and request.sessionId
        else []
    )
    prompt = create_nl_prompt(request.query, request.language, request.task, history)
    response_text = query_ollama(prompt, request.model)

    has_code = bool(re.search(r"```[a-zA-Z]*\n[\s\S]*?```", response_text))
    response = {
        "response": response_text,
        "tone": "code" if has_code else "conversation",
    }

    if request.sessionId:
        session = get_session_by_id(request.sessionId)
        if not session:
            session = {
                "id": request.sessionId,
                "name": f"Chat {datetime.now().strftime('%Y-%m-%d, %H:%M:%S')}",
                "messages": [],
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
            }

        now = datetime.now().isoformat()
        session["messages"].append(
            {"content": request.query, "isUser": True, "timestamp": now}
        )
        session["messages"].append(
            {"content": response_text, "isUser": False, "timestamp": now}
        )
        session["updated_at"] = now
        save_session_file(request.sessionId, session)

    return response
