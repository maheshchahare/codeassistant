"""
Prompt templates for different code tasks.
Enhanced prompts for better LLM responses.
"""

from typing import List, Optional, Dict

# Task-specific prompts with improved language
TASK_PROMPTS = {
    "improve": "Improve this code to make it cleaner, more maintainable, and follow best practices.",
    "document": "Add appropriate documentation to this code following best practices.",
    "refactor": "Refactor this code to improve its structure while preserving functionality.",
    "optimize": "Optimize this code for better performance while maintaining readability.",
    "debug": "Identify and fix potential bugs or issues in this code.",
    "query": "Answer the following programming question or help with the code task.",
}


def create_nl_prompt(
    query: str, language: Optional[str] = None, task: Optional[str] = None, history: List[Dict] = None
) -> str:
    """
    Create a natural language prompt for the LLM with improved formatting and context.
    
    Args:
        query: The user's question or request
        language: Optional programming language to focus on
        task: Optional specific task type
        history: Optional conversation history for context
    
    Returns:
        A formatted prompt string
    """
    # Format language context
    language_context = f"for {language} programming" if language else "for programming in general"
    
    # Format task description
    task_description = ""
    if task and task in TASK_PROMPTS:
        task_description = f"The user wants me to {TASK_PROMPTS[task].lower()}"
    
    # Format conversation history
    history_context = ""
    if history and len(history) > 0:
        history_formatted = "\n\n".join(
            [
                f"USER: {msg['content']}\n\nASSISTANT: {history[i+1]['content'] if i+1 < len(history) else ''}"
                for i, msg in enumerate(history) if msg['role'] == 'user' and i+1 < len(history)
            ]
        )
        history_context = f"\n\n### Previous Conversation:\n{history_formatted}\n\n"
    
    # Main system prompt with detailed instructions
    system_instructions = f"""You are an expert software engineer and programming mentor with deep knowledge {language_context}.
Your goal is to provide clear, helpful, and accurate guidance.

{task_description}

## Guidelines:
- Provide detailed explanations that help the user understand concepts deeply
- Include code examples when relevant, formatted with proper syntax highlighting
- Be concise but thorough, focusing on best practices
- When discussing code, emphasize:
  * Readability and maintainability
  * Proper error handling
  * Modularity and separation of concerns
  * Efficient algorithms and data structures
  * Modern language features and idioms
  * Security considerations

## Format:
- For code snippets, use triple backticks with the language name: ```{language or "language"}
- For important concepts, use **bold** text
- Use headings for different sections with ### or ## as appropriate
- For lists, use proper markdown formatting with - or 1. 2. 3.
"""

    # Build the complete prompt
    prompt = f"""{system_instructions}{history_context}

### Current Question:
{query}

### Your detailed response (include code snippets where appropriate):
"""

    return prompt


def create_code_prompt(
    code: str, language: str, task: str, context: Optional[str] = None
) -> str:
    """
    Create a prompt for the LLM to process code with improved instructions.
    
    Args:
        code: The source code to be processed
        language: The programming language of the code
        task: The type of task to perform on the code
        context: Optional additional context about the code
    
    Returns:
        A formatted prompt string
    """
    task_description = TASK_PROMPTS.get(task, TASK_PROMPTS["improve"])
    
    # Include context if provided
    context_section = ""
    if context:
        context_section = f"""
## Context
{context}
"""

    prompt = f"""# Code Review and Improvement Task

## Task Description
As an expert software engineer, your task is to {task_description.lower()} 

## Programming Language
{language}
{context_section}

## Original Code
```{language}
{code}
