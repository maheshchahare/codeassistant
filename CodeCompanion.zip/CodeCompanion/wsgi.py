from werkzeug.middleware.proxy_fix import ProxyFix
from main import app

# Add proxy fix middleware
app.middleware_stack = ProxyFix(app.middleware_stack, x_proto=1, x_host=1)

# For Gunicorn to use
application = app